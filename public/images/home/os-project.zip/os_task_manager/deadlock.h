#ifndef DEADLOCK_H
#define DEADLOCK_H

void detect_deadlock();

#endif


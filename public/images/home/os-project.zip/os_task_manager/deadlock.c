#include <stdio.h>
#include <stdlib.h>
#include "deadlock.h"

void detect_deadlock() {
    FILE *fp;
    char line[256];
    int found = 0;

    printf("\nProcesses waiting on locks (State = D)\n");
    printf("PID    COMMAND\n");
    printf("----------------------\n");

    fp = popen("ps -e -o pid,stat,comm --no-headers | grep ' D'", "r");
    if (!fp) {
        perror("deadlock check failed");
        return;
    }

    while (fgets(line, sizeof(line), fp)) {
        printf("%s", line);
        found = 1;
    }

    pclose(fp);

    if (!found)
        printf("✅ No deadlock detected\n");
    else
        printf("\n⚠ Above processes are blocked on kernel locks\n");

    printf("\nPress Enter to go back...");
    getchar(); getchar();
}


#include <stdio.h>
#include <stdlib.h>
#include "process_manager.h"
#include "deadlock.h"
#include "cpu_scheduler.h"
#include "custom_process.h"
#include "resources_ipc.h"

int main() {
    int choice;
    while(1) {
        printf("\n==== OS TASK MANAGER ====\n");
        printf("1. Show Task List\n");
        printf("2. Deadlock Detection\n");
        printf("3. CPU Scheduling Info\n");
        printf("4. Create Custom Processes\n");
        printf("5. Show Processes Sharing Resources\n");
        printf("6. Show Processes Using IPC\n");
        printf("0. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
        getchar(); // consume newline

        switch(choice) {
            case 1: list_processes(); break;
            case 2: detect_deadlock(); break;         // match deadlock.c function
            case 3: show_all_scheduling(); break;     // match cpu_scheduler.c function
            case 4: create_custom_process(); break;
            case 5: show_shared_resources(); break;
            case 6: show_ipc_communication(); break;
            case 0: exit(0);
            default: printf("Invalid choice\n");
        }
    }
    return 0;
}


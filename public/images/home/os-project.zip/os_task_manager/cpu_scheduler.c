#include <stdio.h>
#include <dirent.h>
#include <ctype.h>
#include <sched.h>
#include <stdlib.h>
#include "cpu_scheduler.h"

void show_all_scheduling() {
    DIR *dir = opendir("/proc");
    struct dirent *ent;

    if (!dir) {
        perror("/proc open failed");
        return;
    }

    printf("\nPID     SCHEDULING POLICY\n");
    printf("------------------------------\n");

    while ((ent = readdir(dir)) != NULL) {
        if (isdigit(ent->d_name[0])) {
            int pid = atoi(ent->d_name);
            int policy = sched_getscheduler(pid);

            printf("%-7d ", pid);
            if (policy == SCHED_OTHER) printf("CFS\n");
            else if (policy == SCHED_FIFO) printf("FIFO\n");
            else if (policy == SCHED_RR) printf("ROUND ROBIN\n");
            else printf("UNKNOWN\n");
        }
    }

    closedir(dir);
    printf("\nPress Enter to go back...");
    getchar(); getchar();
}


#ifndef CUSTOM_PROCESS_H
#define CUSTOM_PROCESS_H

void create_custom_process();

#endif


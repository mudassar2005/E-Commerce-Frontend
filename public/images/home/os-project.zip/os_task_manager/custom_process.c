#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sched.h>
#include "custom_process.h"

typedef struct {
    char name[32];
    char message[64];
    int priority;
    pid_t pid;
} Process;

#define MAX_PROCESSES 100
Process queue[MAX_PROCESSES];
int queue_size = 0;

void sort_by_priority(Process arr[], int size) {
    for (int i = 0; i < size-1; i++) {
        for (int j = i+1; j < size; j++) {
            if (arr[j].priority > arr[i].priority) {
                Process temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
}

void create_custom_process() {
    int n, scheduling;
    printf("Enter number of custom processes to create (0 to go back): ");
    scanf("%d", &n);
    getchar();
    if (n == 0) return;
    if (n > MAX_PROCESSES) n = MAX_PROCESSES;

    printf("Select Scheduling for all processes:\n");
    printf("1.CFS  2.FIFO  3.ROUND ROBIN  4.PRIORITY\nChoice: ");
    scanf("%d", &scheduling);
    getchar();

    for (int i = 0; i < n; i++) {
        printf("\nProcess %d name: ", i + 1);
        fgets(queue[i].name, sizeof(queue[i].name), stdin);
        queue[i].name[strcspn(queue[i].name, "\n")] = 0;

        char temp_name[32];
        strncpy(temp_name, queue[i].name, sizeof(temp_name)-1);
        temp_name[31] = '\0';

        snprintf(queue[i].message, sizeof(queue[i].message),
                 "I am %s & I run 1 time", temp_name);

        if (scheduling == 4) {
            printf("Enter priority (1-99) for %s: ", queue[i].name);
            scanf("%d", &queue[i].priority);
            if (queue[i].priority < 1) queue[i].priority = 1;
            if (queue[i].priority > 99) queue[i].priority = 99;
            getchar();
        } else {
            queue[i].priority = 0;
        }
    }
    queue_size = n;

    if (scheduling == 4) {
        sort_by_priority(queue, queue_size);
    }

    const char *sched_name;
    if (scheduling == 1) sched_name = "CFS";
    else if (scheduling == 2) sched_name = "FIFO";
    else if (scheduling == 3) sched_name = "ROUND ROBIN";
    else if (scheduling == 4) sched_name = "PRIORITY";
    else sched_name = "UNKNOWN";

    printf("\n=== Running Custom Processes ===\n");
    for (int i = 0; i < queue_size; i++) {
        pid_t pid = fork();
        if (pid < 0) {
            perror("fork failed");
            exit(1);
        } else if (pid == 0) {
            printf("PID: %d | Scheduling: %s", getpid(), sched_name);
            if (scheduling == 4)
                printf(" | Priority: %d", queue[i].priority);
            printf(" | Message: %s\n", queue[i].message);
            exit(0);
        } else {
            queue[i].pid = pid;
        }
    }

    for (int i = 0; i < queue_size; i++) {
        waitpid(queue[i].pid, NULL, 0);
    }

    printf("\nAll processes finished running.\n");
    printf("Press Enter to go back...");
    getchar();
}


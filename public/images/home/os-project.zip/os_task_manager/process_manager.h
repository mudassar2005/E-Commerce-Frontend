#ifndef PROCESS_MANAGER_H
#define PROCESS_MANAGER_H

void list_processes();

#endif


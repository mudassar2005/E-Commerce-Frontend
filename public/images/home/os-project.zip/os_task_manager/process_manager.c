#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "process_manager.h"

void list_processes() {
    FILE *fp;
    char line[256];
    uid_t myuid = getuid();

    printf("\nPID   PPID  USER     CPU%%    RAM%%        KILL  COMMAND\n");
    printf("----------------------------------------------------------------\n");

    fp = popen("ps -e -o pid,ppid,user,%cpu,%mem,uid,comm --no-headers", "r");
    if (!fp) {
        perror("ps failed");
        return;
    }

    while (fgets(line, sizeof(line), fp)) {
        int pid, ppid, uid;
        char user[32], cmd[64];
        float cpu, mem;

        sscanf(line, "%d %d %s %f %f %d %s",
               &pid, &ppid, user, &cpu, &mem, &uid, cmd);

        int can_kill = (uid == myuid);

        printf("%-5d %-5d %-8s %-6.2f %-6.2f   %-4s  %s\n",
               pid, ppid, user, cpu, mem, can_kill ? "YES" : "NO", cmd);
    }

    pclose(fp);
    printf("\nPress Enter to go back...");
    getchar(); getchar();
}


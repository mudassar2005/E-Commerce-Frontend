#ifndef RESOURCES_IPC_H
#define RESOURCES_IPC_H

void show_shared_resources();
void show_ipc_communication();

#endif


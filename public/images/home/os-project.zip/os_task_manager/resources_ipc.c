#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/types.h>
#include "resources_ipc.h"

#define MAX_PROCESSES 1024
#define MAX_RESOURCES 1024
#define MAX_NAME_LEN 64

typedef struct {
    char path[256];           // memory-mapped file path
    pid_t pids[MAX_PROCESSES]; // PIDs using this resource
    int count;                 // number of PIDs
} SharedResource;

// Utility: check if string contains substring
int contains(const char* str, const char* substr) {
    return strstr(str, substr) != NULL;
}

void show_shared_resources() {
    DIR *proc = opendir("/proc");
    struct dirent *entry;
    char line[512];

    SharedResource resources[MAX_RESOURCES];
    int res_count = 0;

    while ((entry = readdir(proc)) != NULL) {
        if (entry->d_type != DT_DIR) continue;
        int pid = atoi(entry->d_name);
        if (pid <= 0) continue;

        char maps_path[64];
        snprintf(maps_path, sizeof(maps_path), "/proc/%d/maps", pid);
        FILE *fp = fopen(maps_path, "r");
        if (!fp) continue;

        while (fgets(line, sizeof(line), fp)) {
            // Only consider actual file paths
            char *file_path = strchr(line, '/');
            if (!file_path) continue;

            // Skip newline
            file_path[strcspn(file_path, "\n")] = 0;

            // Check if this resource already exists
            int found = 0;
            for (int i = 0; i < res_count; i++) {
                if (strcmp(resources[i].path, file_path) == 0) {
                    resources[i].pids[resources[i].count++] = pid;
                    found = 1;
                    break;
                }
            }

            if (!found && res_count < MAX_RESOURCES) {
                strncpy(resources[res_count].path, file_path, sizeof(resources[0].path)-1);
                resources[res_count].path[sizeof(resources[0].path)-1] = '\0';
                resources[res_count].pids[0] = pid;
                resources[res_count].count = 1;
                res_count++;
            }
        }
        fclose(fp);
    }
    closedir(proc);

    // Print resources shared by more than 1 process
    printf("\n=== Shared Memory-Mapped Files ===\n");
    for (int i = 0; i < res_count; i++) {
        if (resources[i].count > 1) { // only show shared
            printf("\nResource: %s\n", resources[i].path);
            for (int j = 0; j < resources[i].count; j++) {
                printf("  PID %d\n", resources[i].pids[j]);
            }
        }
    }

    printf("\nPress Enter to go back...");
    getchar();
}

void show_ipc_communication() {
    DIR *proc = opendir("/proc");
    struct dirent *entry;

    printf("\nProcesses using IPC (pipes / sockets / msg queues):\n");

    while ((entry = readdir(proc)) != NULL) {
        if (entry->d_type != DT_DIR) continue;
        int pid = atoi(entry->d_name);
        if (pid <= 0) continue;

        char fd_path[64];
        snprintf(fd_path, sizeof(fd_path), "/proc/%d/fd", pid);
        DIR *fd_dir = opendir(fd_path);
        if (!fd_dir) continue;

        struct dirent *fd_entry;
        char fd_link[512];
        char fd_target[512];

        while ((fd_entry = readdir(fd_dir)) != NULL) {
            snprintf(fd_link, sizeof(fd_link), "%s/%s", fd_path, fd_entry->d_name);
            ssize_t len = readlink(fd_link, fd_target, sizeof(fd_target)-1);
            if (len != -1) {
                fd_target[len] = '\0';
                if (contains(fd_target, "pipe") || contains(fd_target, "socket")) {
                    printf("PID %d uses IPC: %s\n", pid, fd_target);
                }
            }
        }
        closedir(fd_dir);
    }

    closedir(proc);
    printf("\nPress Enter to go back...");
    getchar();
}


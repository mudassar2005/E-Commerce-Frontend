#ifndef CPU_SCHEDULER_H
#define CPU_SCHEDULER_H

void show_all_scheduling();

#endif

